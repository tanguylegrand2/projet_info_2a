## Méthode à utiliser pour créer la base de données:
## Affecter True à une variable au choix et False aux autres.
passer_par_les_distances = False
passer_par_les_segments = False
conserver_les_matchs_par_rectangles_uniquement = True

## Espace de stockage disque à utiliser:
chemin_local = "C:/Users/lucas/Documents/projet_info/projet_info_2a/données/"

## Seuil de proximité (en mètres) pour la fonction distance si passer_par_les_distances est défini
## sur True:
seuil = 30

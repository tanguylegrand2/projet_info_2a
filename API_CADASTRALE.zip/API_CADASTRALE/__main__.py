from Controler_layer.control_layer import ControlLayer

# Lancement de l'API
ControlLayer().lancer()
